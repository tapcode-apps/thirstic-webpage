# Thirstic

The first _smart_ water tracker and reminder that automatically adapts to your activity and the weather conditions.

## Description

Doing your regular workout on Tuesday and Thursday evening? Thirstic will learn the patterns and update your suggested water intake automatically. Heatwave on the horizont? Thirstic has you covered! Your suggested water intake will automatically increase.

Drinking enough water is important for your health. Thirstic encourages you to drink and log your water intake during your day. The app has a simple and straightforward user interface with no ads and keeps all your private data securely on your device.

This is the first app that automatically updates your estimated water needs in the background and sends you reminders as soon as you reach your preferred water needs threshold. For example, Thirstic will send you a notification if it's time to drink another 300ml (10 fl oz).

In addition to your activity, your daily water intake goal changes depending on your local weather conditions (in-app purchase required). In the app settings, you can customize the parameters of your water needs estimation to your preferences, resulting in higher or lower daily intake goals.

Thirstic works best if you have daily data for active and resting energy in your Health app. Otherwise, the app will use the step counter from your iPhone to estimate your daily activity.

Privacy and data security is a key concept of Thirstic. The advanced calculations in this app are powered by the computing power of your iPhone. Your water intake is stored securely in your Health app. Thirstic does *not* send your activity or health data to remote servers.

## Key Features

- Helps you drinking enough water during your day by taking into account your activity and the weather
- Adapts to your activity by learning patterns and automatically updating your suggested water intake
- Adapts to weather conditions by increasing your suggested water intake on hot days
- Assists you drinking water in small amounts throughout your day, instead of only emphasizing your total water intake goal
- Sends you notifications if you reach a specified „thirst threshold“ (for example 300 ml or 10 fl oz)
- Allows to change the parameters of your water needs estimation, resulting in higher or lower daily water intake goals
- Features a minimalistic and straightforward user interface that allows to log your water intake with a single tap
- No health or activity data leaves your device and your water intake is securely stored in your Health app

## Author and company details

Thirstic was developed by Johannes Erschbamer (@ersjoh), an indie iOS developer from South Tyrol, Italy. You can read more about him on his company website [tapcode.co/about](https://tapcode.co/about).

Tapcode is a small, privately-held business located in the middle of the beautiful Alps in Italy.

## Business Model and app pricing 

- We do not collect or sell any user data.
- We do not display ads or use invasive external analytics frameworks.
- Users can use the basic functionality completely for free.
- More advanced features (weather reports, some preferences) require an in-app subscription (quarterly/yearly) OR a one-time purchase.

## Links

- [Full disclaimer](https://thirstic.app/disclaimer)
- [Terms & Conditions](https://thirstic.app/terms)
- [Privacy Policy](https://thirstic.app/privacypolicy)
