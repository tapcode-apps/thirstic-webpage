# Thirstic

The first _smart_ water drink reminder that automatically adapts to your activity and weather conditions.

## Key Features

- Helps you drinking enough water during your day by taking into account your activity and weather conditions in your area.
- Adapts to your activity by learning patterns and updating your suggested water intake automatically in the background.
- Adapts to weather conditions by increasing your suggested water intake toal on hot days.
- Assists you drinking water in small amounts throughout your day, instead of emphasizing your total daily water intake goal only.
- Sends you notifications if you reach a specified „thirst threshold“ (for example 300 ml or 10 fl oz).
- Change the parameters of your water intake estimate, resulting in higher or lower daily water intake goals.
- A minimalistic and straightforward user interface allows you to add your water intake with a single tap.
- Works best with fitness trackers that store burned calories into Health. Otherwise, the app will use the step counter from your iPhone.
- Private and secure. No health or activity data leaves your device and is securely stored in your Health app.

## Author and company details

Thirstic was developed by Johannes Erschbamer (@ersjoh), an indie iOS developer from South Tyrol, Italy. You can read more about him on this company website [tapcode.co/about](https://tapcode.co/about).

Tapcode is his small, privately-held business located in the middle of the beautiful Alps.

## App pricement

- We do not collect or sell any user data.
- We do not display ads or use invasive external analytics frameworks.
- Users can use the basic functionality completely for free.
- More advanced features (weather reports, some preferences) require an in-app subscription (quarterly/yearly) OR a one-time purchase.
